﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo9bGuia3
{
    internal class Venta
    {
        private string nombreProducto;
        private double valorProducto;
        private double descuento;
        private bool ticket;
        private bool esNuevo;

        public double Descuento { 
            get { return descuento; } 
        }
        public string NombreProducto
        {
            get { return nombreProducto; }
            set { nombreProducto = value; }
        }

        public double ValorProducto
        {
            get { return valorProducto; }
            set { valorProducto = value; }
        }

        public bool Ticket { 
            get { return ticket; }
            set { ticket = value;}
        }
        public bool EsNuevo
        {
            get { return esNuevo; }
            set { esNuevo = value; }
        }

        public double VentaProducto()
        {

            //if (esNuevo)
            //    descuento = valorProducto * 0.1;
            //else
            //    descuento = valorProducto * 0.25;

            descuento = esNuevo ? valorProducto * 0.1 : valorProducto * 0.25;
            ticket = valorProducto > 500 ? true : false;

            return valorProducto - descuento;
        }


    }
}
