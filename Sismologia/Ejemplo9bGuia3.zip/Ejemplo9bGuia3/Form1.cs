﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejemplo9bGuia3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Venta productoVendido = new Venta();
        private void limpiar()
        {
            txtNombre.Clear();
            txtPrecio.Clear();
            rbtNuevo.Checked = false;
            rbtUsado.Checked = false;
            txtNombre.Focus();
        }
        private void btnAceptar_Click(object sender, EventArgs e)
        {
            productoVendido.ValorProducto = double.Parse(txtPrecio.Text);
            productoVendido.EsNuevo = rbtNuevo.Checked  ? true : false;

            productoVendido.VentaProducto();
            
            txtPrecioBruto.Text = productoVendido.ValorProducto.ToString();
            txtDescuentos.Text = productoVendido.Descuento.ToString();
            txtTicket.Text = productoVendido.Ticket? "$50.00":"$0.00";

            limpiar();

        }
    }
}
